%% ReadMe File of Group-4 for the Miniproject-2 of ECSE-551: Machine Learning for Engineers %%
-----------------------------------------------------------------------------------------------

## Performed Text Analysis on the Comments ##
-Project is made by:
 1) Alok Patel (260954024)
 2) Aishwarya Ramamurthy (260963956)
 3) Katyayani Prakash (260964511)

-----------------------------------------------------------------------------------------------

%% Instruction to Run the Code %%
- The code can be opened as shown below:
  i) Search for the Google Colab by visiting "www.google.com"
  ii) Open the colab website and go to File and in the 'Upload Notebook' upload the file named as 
     "MP-2_ML_Group-4.ipynb"
- Another ReadMe is written at the start of the code.
- You will need two dataset files of the train.csv and test.csv which includes Comments and
  relavent Subreddit (o/p) and the test comments, whose results were needed to be submitted in
  the Kaggle Competition.
- Just follow the instructions written in the code to run the code. 

-----------------------------------------------------------------------------------------------
